#import re as regex
#my_regex = regex.compile('[0-9]',regex.I)

def apply_to_one(f):
    return f(i)

my_double = my_double
x = apply_to_one(my_double)