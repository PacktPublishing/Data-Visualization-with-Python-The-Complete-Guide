#count = 0
#while count<=5:
#    print(count)
#    count+=1;



# Prints out 1,2,3,4
#for i in range(1, 10):
#    if(i%5==0):
#        break
#    print(i)
#else:
#    print("this is not printed because for loop is terminated because of break but not due to failure in condition")

#prints out numbers 0,1,2,3,4
for x in range(5):
    print(x)

#prints out 3,5,7
for x in range(3,8,2):
    print(x)